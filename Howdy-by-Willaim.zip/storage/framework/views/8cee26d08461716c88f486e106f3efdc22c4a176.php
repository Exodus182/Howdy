<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12 mt-2">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('home')); ?>" class="text-decoration-none text-reset">Home</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url('history')); ?>" class="text-decoration-none text-reset">Riwayat Pemesanan</a></li>
                <li class="breadcrumb-item active" aria-current="page">Detail Pemesanan</li>
            </ol>
        </nav>
        </div>
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h3><i class="fa-solid fa-circle-check"></i> Check Out</h3>
                    <h5>Pesanan Anda Sudah Berhasil Check Out. Untuk Melakukan Pembayaran, Silahkan Transfer di Rekening <span class="fw-bold">Bank Negara: 32151-859320-456</span> dengan Nominal: <span class="fw-bold">Rp. <?php echo e(number_format($order->unique_code + $order->subtotal)); ?></span></h5>
                </div>
            </div>
            <?php if(!empty($order)): ?>
            <p class="text-end">Tanggal Pesan: <?php echo e($order->date); ?></p>
            <div class="card">
            <div class="card-header">
            <h3 class="mt-2"><i class="fa-solid fa-cart-shopping"></i> Detail Pemesanan</h3>
            </div>
            <div class="card-body">
            <table class="table table-striped">
            <thead class="text-center">
                <tr>
                    <th>No.</th>
                    <th>Gambar</th>
                    <th>Nama Pakaian</th>
                    <th>Jumlah Pakaian</th>
                    <th>Total</th>
                    <th>Subtotal</th>
                </tr>
            </thead>
            <tbody>
                <?php $no=1 ?>
                <?php $__currentLoopData = $order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center"><?php echo e($no++); ?>.</td>
                    <td><img src="<?php echo e(url('uploads')); ?>/<?php echo e($order_detail->item->image); ?>" width="100px" alt="Produk"></td>
                    <td class="text-end"><?php echo e($order_detail->item->item_name); ?></td>
                    <td class="text-end"><?php echo e($order_detail->total); ?></td>
                    <td class="text-end">Rp. <?php echo e(number_format($order_detail->item->price)); ?></td>
                    <td class="text-end"><?php echo e(number_format($order_detail->subtotal)); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr class="fw-bold">
                    <td colspan="5" class="text-end">Subtotal Biaya:</td>
                    <td class="text-end">Rp. <?php echo e(number_format($order->subtotal)); ?></td>
                </tr>
                <tr class="fw-bold">
                    <td colspan="5" class="text-end">Kode Unik:</td>
                    <td class="text-end">Rp. <?php echo e(number_format($order->unique_code)); ?></td>
                </tr>
                <tr class="fw-bold">
                    <td colspan="5" class="text-end">Total yang Harus Ditransfer:</td>
                    <td class="text-end">Rp. <?php echo e(number_format($order->unique_code + $order->subtotal)); ?></td>
                </tr>
            </tbody>
            </table>
            <?php endif; ?>
            </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\apps\HowdyWS\resources\views/history/detail.blade.php ENDPATH**/ ?>