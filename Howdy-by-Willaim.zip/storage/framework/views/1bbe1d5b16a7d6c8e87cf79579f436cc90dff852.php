<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12 mt-2">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('home')); ?>" class="text-decoration-none text-reset">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page"><?php echo e($item->item_name); ?></li>
            </ol>
        </nav>
        </div>
        <div class="col-md-12 my-2">
            <div class="card rounded">
                <div class="card-header">
                    <h3 class="ms-2 my-2 text-center fw-bold"><?php echo e($item->item_name); ?></h3>
                </div>
                <div class="card-body">
                <div class="row">
                    <div class="col-md-5">
                        <img src="<?php echo e(url('uploads')); ?>/<?php echo e($item->image); ?>" class="rounded mx-auto d-block" width="100%" height="450px" alt="Produk">
                    </div>
                    <div class="col-md-7">
                    <table class="table table-borderless">
                        <tbody>
                            <tr>
                                <td>Harga</td>
                                <td>:</td>
                                <td>Rp. <?php echo e(number_format($item->price)); ?></td>
                            </tr>
                            <tr>
                                <td>Stok</td>
                                <td>:</td>
                                <td><?php echo e($item->stock); ?></td>
                            </tr>
                            <tr>
                                <td>Keterangan</td>
                                <td>:</td>
                                <td><?php echo e($item->description); ?></td>
                            </tr>
                                <tr>
                                    <td>Jumlah Pesan</td>
                                    <td>:</td>
                                    <td>
                                        <form action="<?php echo e(url('order')); ?>/<?php echo e($item->id); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                            <input type="text" name="order_number" class="form-control" required>
                                            <hr>
                                            <button type="submit" class="btn btn-success mt-3"><i class="fa-solid fa-plus"></i> Produk ke Keranjang</button>
                                        </form>
                                    </td>
                                </tr>
                        </tbody>
                    </table>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\apps\HowdyWS\resources\views/order/index.blade.php ENDPATH**/ ?>