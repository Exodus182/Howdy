

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12 mt-2">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('home')); ?>" class="text-decoration-none text-reset">Home</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>" class="text-decoration-none text-reset">Admin Menu</a></li>
                <li class="breadcrumb-item active" aria-current="page">Delete Item</li>
            </ol>
        </nav>
        </div>
        <div class="col-md-12">
            <div class="card">
            <div class="card-header">
            <h3 class="mt-2"><i class="fa-solid fa-cart-trash"></i> Delete Item</h3>
            </div>
            <div class="card-body">
            <table class="table table-striped">
            <thead class="text-center">
                <tr>
                    <th>No Id.</th>
                    <th>Nama Pakaian</th>
                    <th>Harga</th>
                    <th>Stock</th>
                    <th>Description</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no=1 ?>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center"><?php echo e($no++); ?>.</td>
                    <td><?php echo e($item->item_name); ?></td>
                    <td>Rp. <?php echo e(number_format($item->price)); ?></td>
                    <td><?php echo e(number_format($item->stock)); ?></td>
                    <td><?php echo e($item->description); ?></td>
                    <td class="text-center">
                        <form action="<?php echo e(url('delete-items')); ?>/<?php echo e($item->id); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Anda yakin ingin menghapus data?');"><i class="fa-solid fa-trash"></i></button>
                        </form>
                        <?php if(session('success')): ?>
                            <p><?php echo e(session('success')); ?></p>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            </table>
            </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\apps\HowdyWS\resources\views/admin/delete-items.blade.php ENDPATH**/ ?>