<?php $__env->startSection('content'); ?>
<div class="container">
    <h3 class="my-3 fw-bold">Produk Kami</h3>
    
    <div class="row justify-content-center owl-carousel owl-theme">
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col">
            <div class="card rounded h-100">
                <img src="<?php echo e(url('storage')); ?>/<?php echo e($item->image); ?>" class="card-img-top" alt="produk" height="300px">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($item->item_name); ?></h5>
                    <table>
                        <tbody>
                            <tr>
                                <td>Harga</td>
                                <td>:</td>
                                <td>&nbsp;Rp. <?php echo e(number_format($item->price)); ?></td>
                            </tr>
                            <tr>
                                <td>Stok</td>
                                <td>:</td>
                                <td>&nbsp;<?php echo e($item->stock); ?></td>
                            </tr>
                            <tr>
                                <td>Keterangan</td>
                                <td>:</td>
                                <td>&nbsp;<?php echo e($item->description); ?></td>
                            </tr>
                        </tbody>
                    </table>
                    
                    <?php if(Auth::user()->role == 1): ?>
                        <hr>
                        <a href="<?php echo e(url('order')); ?>/<?php echo e($item->id); ?>" class="btn btn-success text-center" style="text-align:center;display:block;"><i class="fa-solid fa-cart-shopping"></i> Pesan</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\apps\HowdyWS\resources\views/home.blade.php ENDPATH**/ ?>