

<?php $__env->startSection('title', __('Admin Menu')); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="<?php echo e(url('home')); ?>">Home</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Admin Menu</li>
                </ol>
              </nav>
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">          
                        <h4><i class="fa fa-pencil"></i> Admin Menu</h4>
                        <div class="card-body">
                            <table class="table table-striped">
                            <thead class="text-center">
                                <tr>
                                    <th>No.</th>
                                    <th>Menu</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <?php 
                                    $no = 1;    
                                ?>
                                <tr>
                                    <td>
                                        <?php echo e($no++); ?>

                                    </td>
                                    <td>Add Items</td>
                                    <td>
                                        <a href="<?php echo e(url('add-items')); ?>">
                                            <button class="btn btn-primary btn-sm"><i class="fa fa-pencil"></i></button>
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <?php echo e($no++); ?>

                                    </td>
                                    <td>Update Items</td>
                                    <td>
                                        <a href="<?php echo e(url('update-items')); ?>">
                                            <button class="btn btn-primary btn-sm"><i class="fa fa-pencil"></i></button>
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <?php echo e($no++); ?>

                                    </td>
                                    <td>Delete Items</td>
                                    <td>
                                        <a href="<?php echo e(url('delete-items')); ?>">
                                            <button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-pencil"></i></button>
                                        </a>
                                    </td>
                                </tr>
                            </tbody>
                            </table>
                            </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\apps\HowdyWS\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>