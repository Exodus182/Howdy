<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12 mt-2">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('home')); ?>" class="text-decoration-none text-reset">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Check Out</li>
            </ol>
        </nav>
        </div>
        <div class="col-md-12">
            <?php if(!empty($order)): ?>
            <p class="text-end">Tanggal Pesan: <?php echo e($order->date); ?></p>
            <div class="card">
            <div class="card-header">
            <h3 class="mt-2"><i class="fa-solid fa-cart-shopping"></i> Check Out</h3>
            </div>
            <div class="card-body">
            <table class="table table-striped">
            <thead class="text-center">
                <tr>
                    <th>No.</th>
                    <th>Gambar</th>
                    <th>Nama Pakaian</th>
                    <th>Jumlah Pakaian</th>
                    <th>Total</th>
                    <th>Subtotal</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no=1 ?>
                <?php $__currentLoopData = $order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center"><?php echo e($no++); ?>.</td>
                    <td><img src="<?php echo e(url('uploads')); ?>/<?php echo e($order_detail->item->image); ?>" width="100px" alt="Produk"></td>
                    <td><?php echo e($order_detail->item->item_name); ?></td>
                    <td><?php echo e($order_detail->total); ?></td>
                    <td>Rp. <?php echo e(number_format($order_detail->item->price)); ?></td>
                    <td><?php echo e(number_format($order_detail->subtotal)); ?></td>
                    <td class="text-center">
                        <form action="<?php echo e(url('checkout')); ?>/<?php echo e($order_detail->id); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('DELETE')); ?>

                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Anda yakin ingin menghapus data?');"><i class="fa-solid fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr class="fw-bold">
                    <td colspan="5" class="text-end">Subtotal Biaya:</td>
                    <td>Rp. <?php echo e(number_format($order->subtotal)); ?></td>
                    <td class="text-center">
                        <a href="<?php echo e(url('confirm-checkout')); ?>" class="btn btn-success" onclick="return confirm('Anda yakin ingin Check Out?');"><i class="fa-solid fa-cart-shopping"></i> Check Out</a>
                    </td>
                </tr>
            </tbody>
            </table>
            <?php endif; ?>
            </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\apps\HowdyWS\resources\views/order/checkout.blade.php ENDPATH**/ ?>