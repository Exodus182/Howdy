<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12 mt-2">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('home')); ?>" class="text-decoration-none text-reset">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Riwayat Pemesanan</li>
            </ol>
        </nav>
        </div>
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                <h3 class="mt-2"><i class="fa-solid fa-clock-rotate-left"></i> Riwayat Pemesanan</h3>
                </div>
                <div class="card-body">
                <table class="table table-striped">
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Tanggal</th>
                        <th>Status</th>
                        <th>Jumlah Harga</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; ?>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($no++); ?>.</td>
                        <td><?php echo e($order->date); ?></td>
                        <td>
                            <?php if($order->status == 1): ?>
                                <span>Sudah Pesan & Belum Dibayar</span>
                            <?php else: ?>
                                <span>Sudah Dibayar</span>
                            <?php endif; ?>
                        </td>
                        <td>Rp. <?php echo e(number_format($order->subtotal + $order->unique_code)); ?></td>
                        <td>
                            <a href="<?php echo e(url('history')); ?>/<?php echo e($order->id); ?>" class="btn btn-primary btn-sm"><i class="fa-solid fa-circle-info"></i> Detail</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
                </div>
            </div>
            </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\apps\HowdyWS\resources\views/history/index.blade.php ENDPATH**/ ?>