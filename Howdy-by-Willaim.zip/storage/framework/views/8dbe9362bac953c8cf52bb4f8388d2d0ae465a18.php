<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
    <div class="col-md-12 mt-2">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('home')); ?>" class="text-decoration-none text-reset">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Profil</li>
            </ol>
        </nav>
        </div>

        <div class="col-md-12">
        <div class="card">
            <div class="card-header">
            <h3 class="my-3 fw-bold"><i class="fa-solid fa-user me-2"></i>Profil Diri</h3>
            </div>
            <div class="card-body">
                <table class="table">
                    <tbody>
                        <tr>
                            <td>Nama</td>
                            <td width="10">:</td>
                            <td><?php echo e($user-> name); ?></td>
                        </tr>
                        <tr>
                            <td>Email</td>
                            <td>:</td>
                            <td><?php echo e($user-> email); ?></td>
                        </tr>
                        <tr>
                            <td>No. HP</td>
                            <td>:</td>
                            <td><?php echo e($user-> phone_number); ?></td>
                        </tr>
                        <tr>
                            <td>Alamat</td>
                            <td>:</td>
                            <td><?php echo e($user-> address); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <a href="<?php echo e(url('editprofile')); ?>">
            <button class="btn btn-primary mt-3">
                Edit Profile
            </button>
        </a>
    </div>
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\apps\HowdyWS\resources\views/profile/index.blade.php ENDPATH**/ ?>